"""" 
The idea: It is a game where you play as my GF and you need to collect food that falls from the top. There is
good food and bad food. You start with 10 points. Each time you miss a piece - you lose 1 point. Eating bad food results
in losing 5 points. Let's now leave it as simple as that.
""" 
import pygame
from sys import exit
from random import randint, choice

class Player (pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load ('Graphics\sveta_model.png').convert_alpha()
        self.rect = self.image.get_rect(midbottom = (300, 645))
        self.gravity = 0
        self.jump_sound = pygame.mixer.Sound ('Graphics\jump.mp3')
        self.jump_sound.set_volume(0.2)
    
    def player_movement (self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE] and self.rect.bottom >= 645:
            self.gravity = -22
            self.jump_sound.play()
        if keys[pygame.K_d]: self.rect.x += 6.5
        elif keys[pygame.K_a]: self.rect.x -= 6.5
        
        if self.rect.left > 800: self.rect.right = 0
        elif self.rect.right < 0: self.rect.left = 800
    
    def apply_gravity(self):
        self.gravity += 1
        self.rect.bottom += self.gravity
        if self.rect.bottom > 645: self.rect.bottom = 645
    
    def borders(self):
        if self.rect.left > 800: self.rect.right = 0
        elif self.rect.right < 0: self.rect.left = 800
    
    def gameover (self):
        self.rect.x = 300

    def update(self):
        self.player_movement()
        self.apply_gravity()
        self.borders()

class Onion (pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load ('Graphics\onion.png')
        self.rect = self.image.get_rect(midbottom = (randint(30, 670), -100))
        
    def destroy (self):
        if self.rect.bottom > 800:
            self.kill()
    
    def movement (self):
        self.rect.bottom += 5
        
    def update (self):
        self.destroy()
        self.movement()

class Obstacle (pygame.sprite.Sprite):
    def __init__(self, type):
        super().__init__()
        if type == 'lays':
            self.image = pygame.image.load('Graphics\lays.png').convert_alpha()
        elif type == 'eclair':
            self.image = pygame.image.load ('Graphics\eclair1.png').convert_alpha()
        elif type == 'macaron':
            self.image = pygame.image.load('Graphics\macaron.png').convert_alpha()
        self.rect = self.image.get_rect(midbottom = (randint(30, 670), -100))
    
    def destroy (self):
        if self.rect.y > 800:
            self.kill()
    
    def movement (self):
        global Health_count
        self.rect.bottom += 5
        if self.rect.bottom == 750:
            Health_count -= 1
        
    def update (self):
        self.destroy()
        self.movement()

def health_gain (): 
    global Health_count
    if pygame.sprite.spritecollide(player.sprite, obstacle_group, True):
        if Health_count < 10:
            Health_count += 1
        gain_sound.play()

def health_loss ():
    global Health_count
    if pygame.sprite.spritecollide(player.sprite, onion_group, True):
        Health_count -= 5
        loss_sound.play()

def display_health():
    text_surface = FONT.render('Health: ', True, 'black')
    Health_surface = FONT.render(str(Health_count), True, 'crimson')
    WINDOW.blit(text_surface, (25, 25))
    WINDOW.blit(Health_surface, (25, 75))

def display_score():
    Score = int(pygame.time.get_ticks()/1000)
    score_text_surface = FONT.render('Score: ', True, 'black')
    score_surface = FONT.render (str((Score-time)), True, 'orange')
    WINDOW.blit (score_text_surface, (550 ,25))
    WINDOW.blit (score_surface, (550, 75))

pygame.init()
#essentials
WIDTH, HEIGHT = 700,700
WINDOW = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('Sveta and Food')
CLOCK = pygame.time.Clock()
FONT = pygame.font.Font(None, 50) #make another font (actually no)
main_background = pygame.image.load('Graphics\main_background.png').convert()
bg_music = pygame.mixer.Sound('Graphics\Background_music.mp3')
bg_music.play()
loss_sound = pygame.mixer.Sound ('Graphics\omit_sound.mp3')
loss_sound.set_volume(0.5)
gain_sound = pygame.mixer.Sound ('Graphics\crunch_sound.mp3')
gain_sound.set_volume(0.5)

#groups
player = pygame.sprite.GroupSingle() #initialize a single sprite group for the player
player.add(Player())
obstacle_group = pygame.sprite.Group()
onion_group = pygame.sprite.Group()

#constant variables
Health_count = 10
Time_count = 0
#event
goodspawn_timer = pygame.USEREVENT + 1
pygame.time.set_timer(goodspawn_timer, 1000) # spawn frequency of edibles
badspawn_timer = pygame.USEREVENT + 2
pygame.time.set_timer(badspawn_timer, 1500) #spawn frequency of ONION

game_over = True
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        if not game_over:
            if event.type == goodspawn_timer:
                obstacle_group.add(Obstacle(choice(['lays', 'eclair', 'macaron'])))
            if event.type == badspawn_timer:
                onion_group.add(Onion())
        else:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_r: 
                game_over = False
                Health_count = 10 
                time = int(pygame.time.get_ticks()/1000)
                obstacle_group.empty()
                onion_group.empty()
                player.sprite.gameover()
                
    if not game_over:
        
        WINDOW.blit(main_background, (-10, 0))
        display_health()
        display_score()
        
        player.draw(WINDOW)
        player.update()
        obstacle_group.draw(WINDOW)
        obstacle_group.update()
        onion_group.draw(WINDOW)
        onion_group.update()
        health_gain()
        health_loss()
        
        if Health_count < 0: # Health loss GAMEOVER
            game_over = True
        
    else: #GAMEOVER SCREEN
        WINDOW.fill ('Red')
        restart_surface = pygame.image.load('Graphics\gameover_image.png').convert()
        WINDOW.blit(restart_surface, (0,0))
        
    pygame.display.update()
    CLOCK.tick(60)
    
